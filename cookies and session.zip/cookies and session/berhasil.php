<?php
 setcookie("message", "Maaf, Username atau Password salah", time()+3600);

session_start();
$username = $_POST["username"];
$password = $_POST["password"];

if($username == "informatika" && $password == "q"){
//    echo "new";
        $_SESSION["user"] = $username;
    header("Location: managerf.php");
}
?>

<html>
<head>
  <title>PORTAL LOGIN MANAGEMENT FILE</title>
</head>
<body>
  <h1>Silahkan Masukan Username dan Passowrd Anda.</h1>
  
  <div style="color: red;margin-bottom: 15px;">
    <?php
  
    if(isset($_COOKIE["message"])){
      echo $_COOKIE["message"]; 
    }
    ?>
  </div>
  
  <form method="post" action="">
    <label>Username</label><br>
    <input type="text" name="username" placeholder="Username"><br><br>
    
    <label>Password</label><br>
    <input type="password" name="password" placeholder="Password"><br><br>
    
    <button type="submit">Login</button>
  </form>
</body>
</html>